export const team_members = [
    {
        image: "nde.jpg",
        name: "nfor nde nyambi",
        post: "CEO",
        social_medias: [
            { name: "twitter", link: "#" },
            { name: "facebook-f", link: "#" },
            { name: "instagram", link: "#" },
            { name: "linkedin", link: "#" },
        ],
    },
    {
        image: "duke.jpg",
        name: "kum leslie mua",
        post: "Director",
        social_medias: [
            { name: "twitter", link: "#" },
            { name: "facebook-f", link: "#" },
            { name: "instagram", link: "#" },
            { name: "linkedin", link: "#" },
        ],
    },
    {
        image: "gedeon.jpg",
        name: "soh mangwa gedeon",
        post: "Director",
        social_medias: [
            { name: "twitter", link: "#" },
            { name: "facebook-f", link: "#" },
            { name: "instagram", link: "#" },
            { name: "linkedin", link: "#" },
        ],
    },
    {
        image: "ronard.jpg",
        name: "fon ronard sauh",
        post: "Director",
        social_medias: [
            { name: "twitter", link: "#" },
            { name: "facebook-f", link: "#" },
            { name: "instagram", link: "#" },
            { name: "linkedin", link: "#" },
        ],
    },
];
