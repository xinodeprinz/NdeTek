const data = [
    {
        label: "Username",
        name: "username",
        type: "text",
    },
    {
        label: "Password",
        name: "password",
        type: "password",
    },
];
export default data;
