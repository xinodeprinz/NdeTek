const data = [
    {
        text: "Home",
        href: "/",
    },
    {
        text: "Blog",
        href: "/blogs/football",
    },
    {
        text: "About",
        href: "/about",
    },
    {
        text: "Portfolio",
        href: "/portfolio",
    },
    // {
    //     text: "Papers",
    //     href: "/papers/gce-advanced-level",
    // },
];
export default data;
