// {/* About the Developer / CEO */}
// <div id="the-developper" className="mb-5">
// <div className="container">
//     <div className="row">
//         <div className="col-lg-6">
//             <img
//                 src="/storage/images/nde.jpg"
//                 alt="NdeTek CEO | Nde"
//                 className="img-fluid w-100"
//             />
//         </div>
//         <div className="col-lg-6 d-flex align-items-center">
//             <div>
//                 <h4 className="text-ndetek text-capitalize text-center mb-3">
//                     The Developer / CEO
//                 </h4>
//                 {ceoDescription()}
//             </div>
//         </div>
//     </div>
// </div>
// </div>
// <div id="small-developer" className="container">
// <div className="card">
//     <img
//         src="/storage/images/nde.jpg"
//         className="card-img-top"
//         alt="NdeTek CEO | Nde"
//     />
//     <div className="card-body">
//         <h5 className="card-title text-ndetek fw-bold">
//             The Developer / CEO
//         </h5>
//         <div className="card-text">{ceoDescription()}</div>
//     </div>
// </div>
// </div>
