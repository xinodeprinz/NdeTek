import React from "react";
import { Link, useForm } from "@inertiajs/inertia-react";
import Swal from "sweetalert2";

const AccountHeader = ({ username, imagePath }) => {
    const form = useForm();
    const logout = (e) => {
        e.preventDefault();
        form.post("/logout", {
            onSuccess: () => {
                new Swal({
                    title: "Success",
                    text: "Logout successful",
                    icon: "success",
                });
            },
        });
    };
    return (
        <div id="header" className="py-3 bg-ndetek text-white">
            <div className="container">
                <div className="d-flex justify-content-between">
                    <Link
                        className="fs-4 fw-bold navbar-brand text-white"
                        href="/"
                    >
                        NdeTek
                    </Link>

                    <div className="dropdown d-flex align-items-center">
                        <img
                            src={`/storage/${imagePath}`}
                            alt={username}
                            style={{
                                width: 60,
                                height: 60,
                                borderRadius: "50%",
                            }}
                        />
                        <div
                            className="dropdown-toggle fs-4 fw-bold text-capitalize ms-2"
                            id="user-dropdown"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >
                            {username}
                        </div>
                        <ul
                            className="dropdown-menu"
                            aria-labelledby="user-dropdown"
                        >
                            <li>
                                <button
                                    className="dropdown-item"
                                    data-bs-toggle="modal"
                                    data-bs-target="#alertModal"
                                >
                                    Delete Account
                                </button>
                            </li>
                            <li>
                                <button
                                    className="dropdown-item"
                                    onClick={logout}
                                >
                                    Logout
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AccountHeader;
