<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
    <img src="https://ndetek.com/storage/images/ndetek-logo.png" class="logo" alt="NdeTek Logo">
</a>
</td>
</tr>
<?php /**PATH D:\React\NdeTek Blog\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>