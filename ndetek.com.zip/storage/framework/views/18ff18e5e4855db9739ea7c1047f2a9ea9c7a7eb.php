<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    
    
    <link rel="shortcut icon" href="/storage/images/favicon.ico">
    <link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/style.css')); ?>" rel="stylesheet" />
    
    

    
    

    
    <script charset="utf-8" src="//cdn.iframe.ly/embed.js?api_key=1a5fdd3651546098c1b8d9"></script>
  
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

    
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:image" content="https://designcode.io/cloud/v2/twitter.jpg" />
    <meta
      name="twitter:title"
      content="NdeTek | The Heart of Technology"
    />
    <meta name="twitter:creator" content="NdeTek | Nde" />
    <meta name="twitter:site" content="https://ndetek.com" />
    <meta
      name="twitter:description"
      content="NdeTek is an upcoming technological company currently based in Buea, Cameroon that aims at training youths in Software Engineering."
    />

    

    
    <meta property="og:type" content="Company" />
    <meta property="og:url" content="https://ndetek.com" />
    <meta
      property="og:title"
      content="NdeTek | The Heart of Technology"
    />
    <meta
      property="og:description"
      content="NdeTek is an upcoming technological company currently based in Buea, Cameroon that aims at training youths in Software Engineering."
    />
    <meta
      property="og:image"
      content="https://ndetek.com/storage/images/ndetek-logo.png"
    />
    
    <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->head; } ?>

    
  </head>
  <body>
    <?php if (!isset($__inertiaSsr)) { $__inertiaSsr = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsr instanceof \Inertia\Ssr\Response) { echo $__inertiaSsr->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/all.js')); ?>"></script>
    
  </body>
</html><?php /**PATH D:\React\NdeTek Blog\resources\views/app.blade.php ENDPATH**/ ?>