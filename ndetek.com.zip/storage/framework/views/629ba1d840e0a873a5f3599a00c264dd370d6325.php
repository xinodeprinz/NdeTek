<?php echo e($slot); ?>

<?php /**PATH D:\React\NdeTek Blog\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>