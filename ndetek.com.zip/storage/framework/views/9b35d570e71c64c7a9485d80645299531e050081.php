[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\React\NdeTek Blog\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>