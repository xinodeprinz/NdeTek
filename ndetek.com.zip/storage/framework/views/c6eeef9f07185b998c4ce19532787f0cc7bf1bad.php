<?php $__env->startComponent('mail::message'); ?>
# Verify your email address

Dear <?php echo e($username); ?>,

Thank you for creating an account on NdeTek.
Your email verification code is: <br>

# <?php echo e($code); ?>




Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH D:\React\NdeTek Blog\resources\views/emails/verify_email.blade.php ENDPATH**/ ?>